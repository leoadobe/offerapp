const http = require('http');
const fs = require('fs/promises');
const path = require('path');
const { URL } = require('url');

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 8787);
const API_ENDPOINT = 'https://publish-p80952-e699446.adobeaemcloud.com/graphql/execute.json/securbank/getOfferByPath';
const PUBLIC_DIR = path.join(__dirname, 'public');
const QUERY_TEMPLATE_FILE = path.join(__dirname, 'query.json');

const MIME_BY_EXT = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(payload));
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function serveStatic(req, res, pathname) {
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const fullPath = path.join(PUBLIC_DIR, safePath);

  if (!fullPath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  try {
    const content = await fs.readFile(fullPath);
    const ext = path.extname(fullPath);
    res.writeHead(200, {
      'Content-Type': MIME_BY_EXT[ext] || 'application/octet-stream',
    });
    res.end(content);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
}

async function readQueryTemplate() {
  try {
    const text = await fs.readFile(QUERY_TEMPLATE_FILE, 'utf8');
    return JSON.parse(text);
  } catch {
    return { offerPath: '/content/dam/securbank/new' };
  }
}

async function handleOffer(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    res.end();
    return;
  }

  if (req.method !== 'POST') {
    sendJson(res, 405, { error: 'Method not allowed' });
    return;
  }

  let body = {};
  try {
    const raw = await readBody(req);
    body = raw ? JSON.parse(raw) : {};
  } catch {
    sendJson(res, 400, { error: 'Invalid JSON body' });
    return;
  }

  const queryTemplate = await readQueryTemplate();
  const offerPath = typeof body.offerPath === 'string' && body.offerPath.trim()
    ? body.offerPath.trim()
    : queryTemplate.offerPath;

  const variables = {
    ...queryTemplate,
    offerPath,
  };

  try {
    const upstream = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ variables }),
    });

    const data = await upstream.json();

    if (!upstream.ok || data.errors) {
      sendJson(res, 502, {
        error: 'Upstream service returned an error',
        details: data.errors || data,
        request: { variables },
      });
      return;
    }

    sendJson(res, 200, {
      request: { variables },
      response: data,
    });
  } catch (error) {
    sendJson(res, 500, {
      error: 'Failed to call upstream service',
      details: error.message,
      request: { variables },
    });
  }
}

const server = http.createServer(async (req, res) => {
  const requestUrl = new URL(req.url, `http://${req.headers.host || `${HOST}:${PORT}`}`);

  if (requestUrl.pathname === '/api/offer') {
    await handleOffer(req, res);
    return;
  }

  await serveStatic(req, res, requestUrl.pathname);
});

server.listen(PORT, HOST, () => {
  // eslint-disable-next-line no-console
  console.log(`Local offer app running at http://${HOST}:${PORT}`);
});
