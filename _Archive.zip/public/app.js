const form = document.getElementById('offer-form');
const offerPathInput = document.getElementById('offerPath');
const statusText = document.getElementById('status');

const webBanner = document.getElementById('web-banner');
const splitLeft = document.getElementById('split-left');

const webPreTitle = document.getElementById('web-pre-title');
const webHeadline = document.getElementById('web-headline');
const webDetail = document.getElementById('web-detail');
const webCta = document.getElementById('web-cta');

const splitPreTitle = document.getElementById('split-pre-title');
const splitHeadline = document.getElementById('split-headline');
const splitDetail = document.getElementById('split-detail');
const splitCta = document.getElementById('split-cta');

function setStatus(message, isError = false) {
  statusText.textContent = message;
  statusText.style.color = isError ? '#a42323' : '#3f4a55';
}

function setBannerImage(url) {
  const safeUrl = url || '';
  webBanner.style.backgroundImage = safeUrl ? `url("${safeUrl}")` : 'none';
  splitLeft.style.backgroundImage = safeUrl ? `url("${safeUrl}")` : 'none';
}

function setTextContent(element, value, fallback = '') {
  element.textContent = value || fallback;
}

function setCta(element, text, href) {
  element.textContent = text || 'See More';
  element.href = href || '#';
  element.target = href ? '_blank' : '_self';
}

function mapOfferToUi(offer) {
  const preTitle = offer.preTitle || '';
  const headline = offer.headline || '';
  const detail = offer.detail?.plaintext || offer.detail?.html || '';
  const ctaText = offer.callToAction || 'See More';
  const ctaUrl = offer.ctaUrl || '';
  const heroImage = offer.heroImage?._publishUrl || '';

  setTextContent(webPreTitle, preTitle);
  setTextContent(webHeadline, headline);
  setTextContent(webDetail, detail);
  setCta(webCta, ctaText, ctaUrl);

  setTextContent(splitPreTitle, preTitle);
  setTextContent(splitHeadline, headline);
  setTextContent(splitDetail, detail);
  setCta(splitCta, ctaText, ctaUrl);

  setBannerImage(heroImage);
}

async function loadOffer(offerPath) {
  setStatus('Loading offer...');

  try {
    const response = await fetch('/api/offer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ offerPath }),
    });

    const payload = await response.json();

    if (!response.ok) {
      throw new Error(payload.details?.[0]?.message || payload.error || 'Failed to load offer');
    }

    const offer = payload.response?.data?.offerByPath?.item;
    if (!offer) {
      throw new Error('No offer item in service response');
    }

    mapOfferToUi(offer);
    setStatus(`Loaded offerPath: ${payload.request?.variables?.offerPath || offerPath}`);
  } catch (error) {
    setStatus(error.message, true);
  }
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const value = offerPathInput.value.trim();
  if (!value) {
    setStatus('Please provide a valid offerPath', true);
    return;
  }
  loadOffer(value);
});

loadOffer(offerPathInput.value.trim());
